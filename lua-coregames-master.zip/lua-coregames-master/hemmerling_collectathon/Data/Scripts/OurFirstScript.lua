-- Comments
--[[
Multi-line 
comments
--]]
print ( "Our first script" )
local aNumber = 10
local aDecimal = 9.99
local aString = "Hey I've got $"
local aBool = true
local aCat = nil

print ( aNumber + aDecimal )
print ( aString .. aNumber + aDecimal .. " in my wallet\n is that a lot?" )

